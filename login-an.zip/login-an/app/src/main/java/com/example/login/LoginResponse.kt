package com.example.login

data class LoginResponse(
    val user: User
)

data class User(
    val id: Int,
    val email: String,
    val password: String
)
