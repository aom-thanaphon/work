package com.example.login.ui.theme

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import android.app.Activity
import android.content.Intent
import androidx.compose.ui.platform.LocalContext
import com.example.login.MainActivity

@Composable
fun HomeScreen() {
    val context = LocalContext.current

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "เข้าสู่ระบบสำเร็จ!",
                fontSize = 24.sp,
                color = MaterialTheme.colorScheme.primary
            )

            Spacer(modifier = Modifier.height(20.dp))

            Text(
                text = "ยินดีต้อนรับเข้าสู่แอปของคุณ 😊",
                fontSize = 16.sp
            )

            Spacer(modifier = Modifier.height(40.dp))

            // ปุ่มออกจากระบบ
            Button(onClick = {
                val intent = Intent(context, MainActivity::class.java)
                context.startActivity(intent)

                // ปิดหน้า HomeActivity
                if (context is Activity) {
                    context.finish()
                }
            }) {
                Text("ออกจากระบบ")
            }
        }
    }
}
