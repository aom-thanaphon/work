<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;

class AuthController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
     public function login(Request $request)
    {
        $email = $request->input('email');
        $password = $request->input('password');

        // ดึงข้อมูล user จากฐานข้อมูล
        $user = DB::table('users')
                  ->where('email', $email)
                  ->first();

        // ตรวจสอบรหัสผ่าน (ยังไม่เข้ารหัส)
        if ($user && $user->password === $password) {
            return response()->json(['message' => 'Login success']);
        } else {
            return response()->json(['message' => 'Invalid credentials'], 401);
        }
    }
}
